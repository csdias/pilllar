﻿namespace Pilllar.Vocal.Api.Helpers
{
    public enum ResourceUriType
    {
        PreviousPage,
        NextPage
    }
}

