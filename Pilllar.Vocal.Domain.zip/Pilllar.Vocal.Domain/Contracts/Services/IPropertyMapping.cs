﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pilllar.Vocal.Domain.Constracts.Services
{
    public interface IPropertyMapping
    {
    }
}
